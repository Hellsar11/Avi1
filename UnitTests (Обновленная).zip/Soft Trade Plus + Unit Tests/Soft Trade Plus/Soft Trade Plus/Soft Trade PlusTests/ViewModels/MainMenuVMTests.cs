﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Soft_Trade_Plus.Models;
using Soft_Trade_Plus.ViewModels;
using Soft_Trade_Plus.ViewModels.Data;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Soft_Trade_Plus.ViewModels.Tests
{
    [TestClass()]
    public class MainMenuVMTests
    {
        MainMenuVM mm = new MainMenuVM();

        [TestMethod("LoadClientsTest")]
        public void LoadClientsTest_3CountNotNull()
        {
            var fakeRepos = new FakeAvicomRepository();
            var clientVM = new MainMenuVM(fakeRepos);

            var resultGetAlls = clientVM.LoadClients();
            var resultCount = clientVM.LoadClients().Count();
            var resultId = clientVM.LoadClients().Where(c => c.ClientName == "Каркасов Олег Максимович").Select(i => i.ClientID);
            foreach(int i in resultId)
            {
                Assert.AreEqual(2, i);
            }
            Assert.IsNotNull(resultGetAlls);
            Assert.AreEqual(3,resultCount);
        }

        [TestMethod("LoadManagersTest")]
        public void LoadManagersTest()
        {
            var fakeRepos = new FakeAvicomRepository();
            var managerVM = new MainMenuVM(fakeRepos);

            var resultGetAlls = managerVM.LoadManagers();
            var resultCount = managerVM.LoadManagers().Count();
            var resultId = managerVM.LoadManagers().Where(c => c.ManagerName == "Гудкова Мария Алексеевна").Select(i => i.ManagerID);
            foreach (int i in resultId)
            {
                Assert.AreEqual(3, i);
            }
            Assert.IsNotNull(resultGetAlls);
            Assert.AreEqual(5, resultCount);
        }

        [TestMethod("LoadProductsTest")]
        public void LoadProducts()
        {
            var fakeRepos = new FakeAvicomRepository();
            var productVM = new MainMenuVM(fakeRepos);

            var resultGetAlls = productVM.LoadProducts();
            var resultCount = productVM.LoadProducts().Count();
            var resultId = productVM.LoadProducts().Where(c => c.ProductName == "Синхронизатор").Select(i => i.ProductID);
            foreach (int i in resultId)
            {
                Assert.AreEqual(2, i);
            }
            Assert.IsNotNull(resultGetAlls);
            Assert.AreEqual(2, resultCount);
        }
    }
}