using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace Soft_Trade_Plus.Models
{
    public partial class ModelAvicom : DbContext
    {
        public ModelAvicom()
            : base("name=ModelAvicom")
        {
        }

        public virtual DbSet<t_Client> t_Client { get; set; }
        public virtual DbSet<t_ClientStatus> t_ClientStatus { get; set; }
        public virtual DbSet<t_Manager> t_Manager { get; set; }
        public virtual DbSet<t_Product> t_Product { get; set; }
        public virtual DbSet<t_ProductType> t_ProductType { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<t_ClientStatus>()
                .HasMany(e => e.t_Client)
                .WithRequired(e => e.t_ClientStatus)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<t_Manager>()
                .HasMany(e => e.t_Client)
                .WithRequired(e => e.t_Manager)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<t_Product>()
                .HasMany(e => e.t_Client)
                .WithRequired(e => e.t_Product)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<t_ProductType>()
                .HasMany(e => e.t_Product)
                .WithRequired(e => e.t_ProductType)
                .WillCascadeOnDelete(false);
        }
    }
}
