﻿using Soft_Trade_Plus.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Soft_Trade_Plus.ViewModels.Data
{
    public interface IAvicomRepository
    {
        List<t_Client> GetAllClients();
        List<t_Manager> GetAllManagers();
        List<t_Product> GetAllProducts();
    }
}
