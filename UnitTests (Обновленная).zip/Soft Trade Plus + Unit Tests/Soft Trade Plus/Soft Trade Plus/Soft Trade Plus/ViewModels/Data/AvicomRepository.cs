﻿using Soft_Trade_Plus.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Soft_Trade_Plus.ViewModels.Data
{
    public class AvicomRepository : IAvicomRepository
    {       
        public List<t_Client> GetAllClients()
        {
            using (ModelAvicom contextAvicom = new ModelAvicom())
            {
                return contextAvicom.t_Client.ToList();
            }           
        }

        public List<t_Manager> GetAllManagers()
        {
            using (ModelAvicom contextAvicom = new ModelAvicom())
            {
                return contextAvicom.t_Manager.ToList();
            }
        }

        public List<t_Product> GetAllProducts()
        {
            using (ModelAvicom contextAvicom = new ModelAvicom())
            {
                return contextAvicom.t_Product.ToList();
            }
        }       
    }
}
