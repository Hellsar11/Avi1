﻿using Soft_Trade_Plus.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Soft_Trade_Plus.ViewModels.Data
{
    public class FakeAvicomRepository : IAvicomRepository
    {

        public List<t_Client> GetAllClients()
        {
            return new List<t_Client>
            {
                new t_Client {ClientID = 1, ClientName = "Олегов Игорь Максимович", ClientStatusID = 1, ManagerID = 2, ProductID = 19},
                new t_Client {ClientID = 2, ClientName = "Каркасов Олег Максимович", ClientStatusID = 1, ManagerID = 2, ProductID = 19},
                new t_Client {ClientID = 3, ClientName = "Соплежуев Василий Игоревич", ClientStatusID = 1, ManagerID = 2, ProductID = 19}
            };
        }

        public List<t_Manager> GetAllManagers()
        {
            return new List<t_Manager>
            {
                new t_Manager {ManagerID = 1, ManagerName = "Ковров Андрей Викторович"},
                new t_Manager {ManagerID = 2, ManagerName = "Маликов Егор Юрьевич"},
                new t_Manager {ManagerID = 3, ManagerName = "Гудкова Мария Алексеевна"},
                new t_Manager {ManagerID = 4, ManagerName = "Фролов Юрий Максимович"},
                new t_Manager {ManagerID = 5, ManagerName = "Крылова Юлия Владимировна"},
            };
        }

        public List<t_Product> GetAllProducts()
        {
            return new List<t_Product>
            {
                new t_Product {ProductID = 1, ProductName = "AutoИнтеллект", ProductPrice = 82000, ProductTypeID = 1, SubscriptionTerm = Convert.ToDateTime("10/10/1010 12:00 AM")},
                new t_Product {ProductID = 2, ProductName = "Синхронизатор", ProductPrice = 24000, ProductTypeID = 2, SubscriptionTerm = Convert.ToDateTime("02/10/2023 12:00 AM")},
            };
        }      
    }
}
