﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Soft_Trade_Plus.ViewModels.Commands
{
    public class MainMenuCommand : ICommand
    {
        readonly Action exec;

        public event EventHandler CanExecuteChanged;

        public MainMenuVM MenuVM { get; set; }

        public MainMenuCommand(MainMenuVM menuVM, Action execute)
        {
            this.MenuVM = menuVM;
            exec = execute;
        }

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            exec.Invoke();
        }
    }
}
