﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Soft_Trade_Plus.Models;
using Soft_Trade_Plus.ViewModels;

namespace Soft_Trade_Plus.Views
{
    /// <summary>
    /// Логика взаимодействия для MainMenu.xaml
    /// </summary>
    public partial class MainMenu : Window
    {
        public MainMenu()
        {
            InitializeComponent();

        }

        private  void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (DataGridManager.SelectedItem != null)
                {
                    if (DataGridManager.SelectedItem is t_Manager)
                    {
                        var row = (t_Manager)DataGridManager.SelectedItem;

                        if (row != null)
                        {
                            tbox_ManagerID.Text = row.ManagerID.ToString();
                            tboxManagerName.Text = row.ManagerName;
                        }
                    }
                }
            }
            catch (Exception ex) {MessageBox.Show(ex.Message);}    
        }

        private void DataGridProducts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (DataGridProducts.SelectedItem != null)
                {
                    if (DataGridProducts.SelectedItem is t_Product)
                    {
                        var row = (t_Product)DataGridProducts.SelectedItem;

                        if (row != null)
                        {
                            tbox_ProductID.Text = row.ProductID.ToString();
                            tboxProdName.Text = row.ProductName;
                            tboxProdPrice.Text = row.ProductPrice.ToString();
                            tboxProdTypeID.Text = row.ProductTypeID.ToString();
                            tboxSubTerm.Text = row.SubscriptionTerm.ToString();
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void DataGridClients_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (DataGridClients.SelectedItem != null)
                {
                    if (DataGridClients.SelectedItem is t_Client)
                    {
                        var row = (t_Client)DataGridClients.SelectedItem;

                        if (row != null)
                        {
                            tbox_ClientID.Text = row.ClientID.ToString();
                            tboxClientName.Text = row.ClientName;
                            tboxStatusID.Text = row.ClientStatusID.ToString();
                            tboxManagerID.Text = row.ManagerID.ToString();
                            tboxProductID.Text = row.ProductID.ToString();
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void tboxManagerName_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text, 0)) return;
            else
                e.Handled = true;
        }

        private void tboxProdName_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text, 0)) return;
            else
                e.Handled = true;
        }

        private void tboxProdPrice_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (Char.IsDigit(e.Text, 0)) return;
            else
                e.Handled = true;
        }

        private void tboxProdTypeID_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (Char.IsDigit(e.Text, 0)) return;
            else
                e.Handled = true;
        }

        private void tboxClientName_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text, 0)) return;
            else
                e.Handled = true;
        }

        private void tboxStatusID_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (Char.IsDigit(e.Text, 0)) return;
            else
                e.Handled = true;
        }

        private void tboxManagerID_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (Char.IsDigit(e.Text, 0)) return;
            else
                e.Handled = true;
        }

        private void tboxProductID_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (Char.IsDigit(e.Text, 0)) return;
            else
                e.Handled = true;
        }
    }
}
