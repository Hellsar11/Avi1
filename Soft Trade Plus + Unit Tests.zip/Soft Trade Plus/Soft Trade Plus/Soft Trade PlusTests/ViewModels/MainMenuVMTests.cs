﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Soft_Trade_Plus.ViewModels;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Soft_Trade_Plus.ViewModels.Tests
{
    [TestClass()]
    public class MainMenuVMTests
    {
        MainMenuVM mm = new MainMenuVM();

        [TestMethod("LoadClientsTest")]
        public void LoadClientsTest()
        {
            var result = mm.LoadClients();
            Assert.IsNotNull(result);
        }

        [TestMethod("LoadManagersTest")]
        public void LoadManagersTest()
        {
            var result = mm.LoadManagers();
            Assert.IsNotNull(result);
        }

        [TestMethod("LoadProductsTest")]
        public void LoadProducts()
        {
            var result = mm.LoadProducts();
            Assert.IsNotNull(result);
        }

        [TestMethod("LoadClientsAndManagersTest")]
        public void LoadClientsAndManagersTest()
        {
            var result = mm.LoadClientsAndManagers();
            Assert.IsNotNull(result);
        }

        [TestMethod("LoadClientsAndProductsTest")]
        public void LoadClientsAndProductsTest()
        {
            var result = mm.LoadClientsAndProducts();
            Assert.IsNotNull(result);
        }

        [TestMethod("LoadClientsAndStatusTest")]
        public void LoadClientsAndStatusTest()
        {
            var result = mm.LoadClientsAndStatus();
            Assert.IsNotNull(result);
        }

    }
}