﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Soft_Trade_Plus.Models;
using Soft_Trade_Plus.ViewModels.Commands;
using Soft_Trade_Plus.Views;

namespace Soft_Trade_Plus.ViewModels
{
    public class MainMenuVM:INotifyPropertyChanged
    {
        public IEnumerable<t_Client> Clients { get { return LoadClients(); } set { OnPropertyChanged(); } }
        public IEnumerable<t_Manager> Managers { get { return LoadManagers(); } set { OnPropertyChanged(); } }
        public IEnumerable<t_Product> Products { get { return LoadProducts(); } set { OnPropertyChanged(); } }
        public object[] CliAndMan { get { return LoadClientsAndManagers(); } set { OnPropertyChanged(); } }
        public object[] CliAndProd { get { return LoadClientsAndProducts(); } set { OnPropertyChanged(); } }
        public object[] CliAndStatus { get { return LoadClientsAndStatus(); } set { OnPropertyChanged(); } }
        public event PropertyChangedEventHandler PropertyChanged;
        public int mmanagerID;
        public int pproductID;
        public int cclientID;
        public string managerName;
        public string prodName;
        public int prodPrice;
        public int prodTypeID;
        public DateTime subTerm;
        public string clientName;
        public int statusID;
        public int managerID;
        public int productID;
        public MainMenuCommand addManager { get; private set; }
        public MainMenuCommand updManager { get; private set; }
        public MainMenuCommand delManager { get; private set; }
        public MainMenuCommand addProduct { get; private set; }
        public MainMenuCommand updProduct { get; private set; }
        public MainMenuCommand delProduct { get; private set; }
        public MainMenuCommand addClient { get; private set; }
        public MainMenuCommand updClient { get; private set; }
        public MainMenuCommand delClient { get; private set; }

        public MainMenuVM()
        {
            this.addManager = new MainMenuCommand(this, AddManager);
            this.updManager = new MainMenuCommand(this, UpdateManager);
            this.delManager = new MainMenuCommand(this, DeleteManager);

            this.addProduct = new MainMenuCommand(this, AddProducts);
            this.updProduct = new MainMenuCommand(this, UpdateProducts);
            this.delProduct = new MainMenuCommand(this, DeleteProducts);

            this.addClient = new MainMenuCommand(this, AddClient);
            this.updClient = new MainMenuCommand(this, UpdateClient);
            this.delClient = new MainMenuCommand(this, DeleteClient);
        }

       
        protected virtual void OnPropertyChanged([CallerMemberName] string PropertyName="")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(PropertyName));
        }

        public int CClientID
        {
            get { return cclientID; }
            set
            {
                cclientID = value;
                OnPropertyChanged();
            }
        }

        public int PProductID
        {
            get { return pproductID; }
            set
            {
                pproductID = value;
                OnPropertyChanged();
            }
        }

        public int MManagerID
        {
            get { return mmanagerID; }
            set
            {
                mmanagerID = value;
                OnPropertyChanged();
            }
        }

        public string ManagerName
        {
            get { return managerName; }
            set
            {
                managerName = value;
                OnPropertyChanged();
            }
        }

        public string ProdName
        {
            get { return prodName; }
            set
            {
                prodName = value;
                OnPropertyChanged();
            }
        }

        public int ProdPrice
        {
            get { return prodPrice; }
            set
            {
                prodPrice = value;
                OnPropertyChanged();
            }
        }

        public int ProdTypeID
        {
            get { return prodTypeID; }
            set
            {
                prodTypeID = value;
                OnPropertyChanged();
            }
        }

        public DateTime SubTerm
        {
            get { return subTerm; }
            set
            {
                subTerm = value;
                OnPropertyChanged();
            }
        }

        public string ClientName
        {
            get { return clientName; }
            set
            {
                clientName = value;
                OnPropertyChanged();
            }
        }

        public int StatusID
        {
            get { return statusID; }
            set
            {
                statusID = value;
                OnPropertyChanged();
            }
        }

        public int ManagerID
        {
            get { return managerID; }
            set
            {
                managerID = value;
                OnPropertyChanged();
            }
        }

        public int ProductID
        {
            get { return productID; }
            set
            {
                productID = value;
                OnPropertyChanged();
            }
        }

        public IEnumerable<t_Client> LoadClients()
        {                    
            using (ModelAvicom contextAvicom = new ModelAvicom())
            {
                var newlist = contextAvicom.t_Client.ToList();
                return newlist;
            } 
            
        }

        public IEnumerable<t_Manager> LoadManagers()
        {
            using (ModelAvicom contextAvicom = new ModelAvicom())
            {
                var newlist = contextAvicom.t_Manager.ToList();
                return newlist;
            }
        }

        public IEnumerable<t_Product> LoadProducts()
        {
            using (ModelAvicom contextAvicom = new ModelAvicom())
            {
                var newlist = contextAvicom.t_Product.ToList();
                return newlist;
            }
        }

        public object [] LoadClientsAndManagers()
        {
            using (ModelAvicom contextAvicom = new ModelAvicom())
            {
                var newlist = contextAvicom.t_Client.Join(contextAvicom.t_Manager, c => c.ManagerID, m => m.ManagerID, (c, m) => new
                {
                    Id = c.ClientID,
                    Name = c.ClientName,
                    Manager = m.ManagerName
                }).ToArray();
                return newlist;
            }
        }

        public object[] LoadClientsAndProducts()
        {
            using (ModelAvicom contextAvicom = new ModelAvicom())
            {
                var newlist = (from t_Client in contextAvicom.t_Client
                              join t_Product in contextAvicom.t_Product on t_Client.ProductID equals t_Product.ProductID
                              join t_ProductType in contextAvicom.t_ProductType on t_Product.ProductTypeID equals t_ProductType.ProductTypeID
                              select new
                              {
                                  Id = t_Client.ClientID,
                                  Name = t_Client.ClientName,
                                  ProdName = t_Product.ProductName,
                                  ProdPrice = t_Product.ProductPrice,
                                  ProdType = t_ProductType.TypeName,
                                  SubTerm = t_Product.SubscriptionTerm
                              }).ToArray();
                return newlist;
            }
        }

        public object[] LoadClientsAndStatus()
        {
            using (ModelAvicom contextAvicom = new ModelAvicom())
            {
                var newlist = contextAvicom.t_Client.Join(contextAvicom.t_ClientStatus, c => c.ClientStatusID, s => s.ClientStatusID, (c, s) => new
                {
                    Id = c.ClientID,
                    Name = c.ClientName,
                    Status = s.StatusName
                }).ToArray();
                return newlist;
            }
 
        }

        public void AddManager()
        {
            try
            {
                using (ModelAvicom contextAvicom = new ModelAvicom())
                {
                    contextAvicom.t_Manager.Add(new t_Manager { ManagerName = ManagerName });
                    contextAvicom.SaveChanges();
                    Managers = contextAvicom.t_Manager.ToList();
                    CliAndMan = LoadClientsAndManagers();
                    CliAndProd = LoadClientsAndProducts();
                    CliAndStatus = LoadClientsAndStatus();
                }
            }
            catch(Exception ex) { MessageBox.Show($"Проверьте корректность данных. Дополнительно: {ex.Message}"); }
        }

        public void UpdateManager()
        {
            try
            {
                using (ModelAvicom contextAvicom = new ModelAvicom())
                {
                    var list = contextAvicom.t_Manager.ToList().Where(m => m.ManagerID == MManagerID);
                    foreach (var newlist in list)
                    {
                        newlist.ManagerName = ManagerName;
                    }
                    contextAvicom.SaveChanges();
                    Managers = contextAvicom.t_Manager.ToList();
                    CliAndMan = LoadClientsAndManagers();
                    CliAndProd = LoadClientsAndProducts();
                    CliAndStatus = LoadClientsAndStatus();
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        public void DeleteManager()
        {
            try
            {
                using (ModelAvicom contextAvicom = new ModelAvicom())
                {
                    var list = contextAvicom.t_Manager.ToArray().Where(m => m.ManagerID == MManagerID);
                    foreach (var newlist in list)
                    {
                        contextAvicom.t_Manager.Remove(newlist);

                    }
                    contextAvicom.SaveChanges();
                    Managers = contextAvicom.t_Manager.ToList();
                    CliAndMan = LoadClientsAndManagers();
                    CliAndProd = LoadClientsAndProducts();
                    CliAndStatus = LoadClientsAndStatus();
                }
            }
            catch(Exception ex) { MessageBox.Show("Перед удалением менеджера, удалите связанного клиента из состояния заказов в таблице (Клиенты)"); }
            
        }

        public void AddProducts()
        {
            try
            {
                using (ModelAvicom contextAvicom = new ModelAvicom())
                {
                    contextAvicom.t_Product.Add(new t_Product { ProductName = ProdName, ProductPrice = prodPrice, ProductTypeID = prodTypeID, SubscriptionTerm = subTerm }) ;
                    contextAvicom.SaveChanges();
                    Products = contextAvicom.t_Product.ToList();
                    CliAndMan = LoadClientsAndManagers();
                    CliAndProd = LoadClientsAndProducts();
                    CliAndStatus = LoadClientsAndStatus();
                }
            }
            catch (Exception ex) { MessageBox.Show($"Проверьте корректность данных. Дополнительно: {ex.Message}"); }
        }

        public void UpdateProducts()
        {
            try
            {
                using (ModelAvicom contextAvicom = new ModelAvicom())
                {
                    var list = contextAvicom.t_Product.ToList().Where(p => p.ProductID == PProductID);
                    foreach (var newlist in list)
                    {
                        newlist.ProductName = ProdName;
                        newlist.ProductPrice = ProdPrice;
                        newlist.ProductTypeID = ProdTypeID;
                        newlist.SubscriptionTerm = SubTerm;
                    }
                    contextAvicom.SaveChanges();
                    Products = contextAvicom.t_Product.ToList();
                    CliAndMan = LoadClientsAndManagers();
                    CliAndProd = LoadClientsAndProducts();
                    CliAndStatus = LoadClientsAndStatus();
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        public void DeleteProducts()
        {
            try
            {
                using (ModelAvicom contextAvicom = new ModelAvicom())
                {
                    var list = contextAvicom.t_Product.ToList().Where(p => p.ProductID == PProductID);
                    foreach (var newlist in list)
                    {
                        contextAvicom.t_Product.Remove(newlist);

                    }
                    contextAvicom.SaveChanges();
                    Products = contextAvicom.t_Product.ToList();
                    CliAndMan = LoadClientsAndManagers();
                    CliAndProd = LoadClientsAndProducts();
                    CliAndStatus = LoadClientsAndStatus();

                }
            }
            catch (Exception ex) { MessageBox.Show("Перед удалением приобретенного товара, удалите связанного клиента из состояния заказов в таблице (Клиент)"); }
        }

        public void AddClient()
        {
            try
            {
                using (ModelAvicom contextAvicom = new ModelAvicom())
                {
                    contextAvicom.t_Client.Add(new t_Client { ClientName = ClientName, ClientStatusID = StatusID, ManagerID = ManagerID, ProductID = ProductID });
                    contextAvicom.SaveChanges();
                    Clients = contextAvicom.t_Client.ToList();
                    CliAndMan = LoadClientsAndManagers();
                    CliAndProd = LoadClientsAndProducts();
                    CliAndStatus = LoadClientsAndStatus();
                }
            }
            catch (Exception ex) { MessageBox.Show($"Проверьте корректность данных. Дополнительно: {ex.Message}"); }
        }

        public void UpdateClient()
        {
            try
            {
                using (ModelAvicom contextAvicom = new ModelAvicom())
                {
                    var list = contextAvicom.t_Client.ToList().Where(p => p.ClientID == CClientID);
                    foreach (var newlist in list)
                    {
                        newlist.ClientName = ClientName;
                        newlist.ClientStatusID = StatusID;
                        newlist.ManagerID = ManagerID;
                        newlist.ProductID = ProductID;
                    }
                    contextAvicom.SaveChanges();
                    Clients = contextAvicom.t_Client.ToList();
                    CliAndMan = LoadClientsAndManagers();
                    CliAndProd = LoadClientsAndProducts();
                    CliAndStatus = LoadClientsAndStatus();
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        public void DeleteClient()
        {
            try
            {
                using (ModelAvicom contextAvicom = new ModelAvicom())
                {
                    var list = contextAvicom.t_Client.ToList().Where(p => p.ClientID == CClientID);
                    foreach (var newlist in list)
                    {
                        contextAvicom.t_Client.Remove(newlist);

                    }
                    contextAvicom.SaveChanges();
                    Clients = contextAvicom.t_Client.ToList();
                    CliAndMan = LoadClientsAndManagers();
                    CliAndProd = LoadClientsAndProducts();
                    CliAndStatus = LoadClientsAndStatus();
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }
}
