namespace Soft_Trade_Plus.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    
    public partial class t_Client
    {
        [Key]
        public int ClientID { get; set; }

        [Required]
        [StringLength(80)]
        public string ClientName { get; set; }

        public int ClientStatusID { get; set; }

        public int ManagerID { get; set; }

        public int ProductID { get; set; }

        public virtual t_ClientStatus t_ClientStatus { get; set; }

        public virtual t_Manager t_Manager { get; set; }

        public virtual t_Product t_Product { get; set; }
    }
}
