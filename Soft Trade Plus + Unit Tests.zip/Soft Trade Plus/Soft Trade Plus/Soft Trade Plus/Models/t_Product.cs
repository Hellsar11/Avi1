namespace Soft_Trade_Plus.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class t_Product
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public t_Product()
        {
            t_Client = new HashSet<t_Client>();
        }

        [Key]
        public int ProductID { get; set; }

        [Required]
        [StringLength(80)]
        public string ProductName { get; set; }

        public int ProductPrice { get; set; }

        public int ProductTypeID { get; set; }

        [Column(TypeName = "date")]
        public DateTime SubscriptionTerm { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<t_Client> t_Client { get; set; }

        public virtual t_ProductType t_ProductType { get; set; }
    }
}
